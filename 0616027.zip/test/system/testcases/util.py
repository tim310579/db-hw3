
class AbstractSuite():
    def setUp():
        print("setup")

    def tearDown():
        print("teardown")
